package com.practice.question13;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PaymentClientService {

    private final RestTemplate restTemplate;

    public PaymentClientService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @CircuitBreaker(name = "paymentService", fallbackMethod = "paymentFallback")
    public PaymentResponse makePayment() {
        return restTemplate.getForObject("http://payment-service/api/pay", PaymentResponse.class);
    }

    // The fallback method must have the exact same return type and take an Exception parameter
    public PaymentResponse paymentFallback(Exception e) {
        return new PaymentResponse("FAILED_FALLBACK", 0.0);
    }
}
