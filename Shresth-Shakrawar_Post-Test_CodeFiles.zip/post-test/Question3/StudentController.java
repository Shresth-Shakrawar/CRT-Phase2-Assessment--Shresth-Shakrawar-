package com.practice.question3;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.HashMap;
import java.util.Map;

@RestController
public class StudentController {

    // The POST endpoint
    @PostMapping("/api/students")
    public ResponseEntity<String> createStudent(@Valid @RequestBody StudentDto student) {
        // If the code reaches here, validation passed.
        return new ResponseEntity<>("Student created successfully", HttpStatus.CREATED);
    }

    // Catches validation errors and returns a 400 Bad Request with the specific messages
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();

        // Extract the specific error messages defined in the DTO
        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
            errors.put(error.getField(), error.getDefaultMessage());
        }

        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }
}
