package com.practice.testing;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private ProductRepository repo; // Creates a fake repository

    @InjectMocks
    private ProductService service; // Injects the fake repo into the real service

    @Test
    void testGetById() {
        // 1. Arrange (Setup the mock)
        Product mockProduct = new Product();
        mockProduct.setId(1L);
        mockProduct.setName("Laptop");

        when(repo.findById(1L)).thenReturn(Optional.of(mockProduct));

        // 2. Act (Call the actual method)
        Product result = service.getById(1L);

        // 3. Assert (Verify the result)
        assertEquals("Laptop", result.getName());
    }
}
